<footer id="globalfoot">
  <div class="gf-content">
    <div class="gf-about">
      <div class="gf-about-case">
        <div class="gf-about-links"> <a class="gf-about-links-item" href="/legal/privacy">Privacy Policy</a> <span class="gf-about-links-space">|</span> <a class="gf-about-links-item" href="/legal/terms"> Terms of Use</a> <span class="gf-about-links-space">|</span> <a class="gf-about-links-item" href="https://www.paotung.org/about/cookie/">Cookies</a> <span class="gf-about-links-space">|</span> <a class="gf-about-links-item" href="/sitemap">Site Map</a> </div>
        <div class="gf-about-copyright"> <span style="letter-spacing: 0.015em">©<?php echo date("Y"); ?>&nbsp;PAOTUNG</span> </div>
      </div>
    </div>
  </div>
</footer>
<?php if ( isset( $addfooter_js ) ) foreach ( $addfooter_js as $key => $value )echo "$value\n"; ?>
</body>
</html>