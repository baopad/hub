<body class="<?php if ( isset( $addbody_class ) ) foreach ( $addbody_class as $key => $value )echo "$value"; ?>" style="<?php if ( isset( $addbody_style ) ) foreach ( $addbody_style as $key => $value )echo "$value"; ?>">
    
<nav id="globalhead">
  <input type="checkbox" id="gh-menustates">
  <div id="gh-content">
    <div class="gh-content-case">
      <div class="gh-logo">
        <div class="gh-logo-case"><a href="/">PAOTUNG</a></div>
      </div>
      <div class="gh-meun">
        <div class="gh-meun-iceo">
          <label class="gh-meun-iceo-label" for="gh-menustates">
          <div class="gh-meun-iceo-label-case">
            <div class="gh-meun-iceo-label-top">
              <div class="gh-meun-iceo-label-top-crust"> </div>
            </div>
            <div class="gh-meun-iceo-label-midd">
              <div class="gh-meun-iceo-label-midd-crust"> </div>
            </div>
            <div class="gh-meun-iceo-label-bottom">
              <div class="gh-meun-iceo-label-bottom-crust"></div>
            </div>
          </div>
          </label>
        </div>
      </div>
      <div class="gh-list">
        <ul class="gh-list-case">
          <li class="gh-list-item"><a href="/services">Services</a> </li>
          <li class="gh-list-item"><a href="/docs">Documentation</a> </li>
          <li class="gh-list-item"><a href="/security">Security</a> </li>
          <li class="gh-list-item"><a href="/downloads">Downloads</a> </li>
          <li class="gh-list-item"><a href="/blog">Blog</a> </li>
          <li class="gh-list-item"><a href="/about">About</a> </li>
        </ul>
      </div>
    </div>
  </div>
</nav>
