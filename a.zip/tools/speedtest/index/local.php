<ul class="gh-list-case">
          <li class="gh-list-item">1M</li>
          <li class="gh-list-item">    </li>
          <li class="gh-list-item"><a href="index/1M.bin">Download</a> </li>
</ul>
<ul class="gh-list-case">
          <li class="gh-list-item">10M</li>
          <li class="gh-list-item">    </li>
          <li class="gh-list-item"><a href="index/10M.bin">Download</a> </li>
</ul>
<ul class="gh-list-case">
          <li class="gh-list-item">100M</li>
          <li class="gh-list-item">    </li>
          <li class="gh-list-item"><a href="index/100M.bin">Download</a> </li>
</ul>
<ul class="gh-list-case">
          <li class="gh-list-item">1000M</li>
          <li class="gh-list-item">    </li>
          <li class="gh-list-item"><a href="index/1000M.bin">Download</a> </li>
</ul>
<?php /*?>
Run Debian
cd /var/www
...
cd tools/speedtest/index
dd if=/dev/zero of=1M.bin bs=1M count=1
dd if=/dev/zero of=10M.bin bs=1M count=10
dd if=/dev/zero of=100M.bin bs=1M count=100
dd if=/dev/zero of=1000M.bin bs=1M count=1000
<?php */?>
