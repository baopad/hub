<main id="localmain"> 
  <!--<input type="checkbox" id="lm-menustates">-->
  <div id="lm-content">
    <div class="lm-content-case"> </div>
  </div>
  <section class="indsec" id="">
    <div class="inddfsec" id="" style="display: none;">
      <div class="col-md-7">
        <div class=" ">
          <h2>本网站的作用</h2>
          <p class="intro"></p>
          <p>　　赋予的权利及其独特的国际性质，本网站可就人类面临的一系列问题采取行动，包括：</p>
          <ul class="ifgddvcro">
            <li class="intgdvcro"><a href="https://www.paotung.org/index.html">Maintain international peace and security</a></li>
            <li class="intgdvcro"><a href="https://www.paotung.org/index.html">Protect </a></li>
            <li class="intgdvcro"><a href="https://www.paotung.org/index.html">Deliver  aid</a></li>
            <li class="intgdvcro"><a href="https://www.paotung.org/index.html">Promote sustainable development</a></li>
            <li class="intgdvcro"><a href="https://www.paotung.org/index.html">Uphold&nbsp;international law</a></li>
          </ul>
          <p></p>
        </div>
      </div>
      <div class="col-md-7">
        <div class=" "> 
          <!--                    <div class="tabs">
                        <div class="tab-pane">
                            <input type="radio" name="tab" id="tab01" checked />
                            <label class="tab-item" for="tab01">tab01</label>
                            <div class="tab-content">111</div>
                        </div>
                        <div class="tab-pane">
                            <input type="radio" name="tab" id="tab02"/>
                            <label class="tab-item" for="tab02">tab02</label>
                            <div class="tab-content">222</div>
                        </div>
                        <div class="tab-pane">
                            <input type="radio" name="tab" id="tab03"/>
                            <label class="tab-item" for="tab03">tab03</label>
                            <div class="tab-content">333</div>
                        </div>
                    </div>-->
          <div class="hfhfnvbg">
            <div class="ghfggfdfdvd">
              <input type="radio" name="tab" id="tab01" checked="">
              <div class="gdfdfsdvd"> <img class="hgjkhkl" src="./unifil.jpg" alt=" " title="Photo/ICJ-CIJ">
                <h4 class="field-content purposes">Maintain International 77</h4>
              </div>
            </div>
            <div class="ghfggfdfdvd">
              <input type="radio" name="tab" id="tab02">
              <div class="gdfdfsdvd"> <img class="hgjkhkl" src="./22.jpg" alt=" " title="Photo/ICJ-CIJ">
                <h4 class="field-content purposes">Maintain International 7222222222222888</h4>
              </div>
            </div>
            <div class="ghfggfdfdvd">
              <input type="radio" name="tab" id="tab03">
              <div class="gdfdfsdvd"> <img class="hgjkhkl" src="./33.jpg" alt=" " title="Photo/ICJ-CIJ">
                <h4 class="field-content purposes">Maintain International 78833333338</h4>
              </div>
            </div>
          </div>
          <div class="owl-dots">
            <label class="tab-item" for="tab01">888
              <button role="button" class="owl-dot active"><span>1111</span></button>
            </label>
            <label class="tab-item" for="tab02">999
              <button role="button" class="owl-dot"><span>222</span></button>
            </label>
            <label class="tab-item" for="tab03">999
              <button role="button" class="owl-dot"><span>288888</span></button>
            </label>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section class="indsec" id="">
    <div class="inddfsec" id=""><br>
      <p>Welcome to paotung.org</p>
      <p> paotung.org is a personal website, community activity with a mission to create,
        maintain, and promote schemas for structured data on the
        Internet, on web pages, in email messages, and beyond. </p>
      <br/>
    </div>
    <!-- mainContent -->
    <div class="inddfsec" style="width: 100%;height: 600px; background-color: aqua;">
      <iframe src="/a/index.html" frameborder="0" id="content-iframe" style="background:#fff;width: 100%;height: 100%"></iframe>
    </div>
    <!--<iframe src="https://www.wjceo.com/examples/threejs/70.html" frameborder="0" id="content-iframe" style="background:#fff;"></iframe>-->
  </section>
</main>
