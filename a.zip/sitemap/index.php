<?php
require_once $_SERVER[ 'DOCUMENT_ROOT' ] . '/layouts/var-layout.php';
require_once $_SERVER[ 'DOCUMENT_ROOT' ] . '/layouts/head-layout.php';
require_once $_SERVER[ 'DOCUMENT_ROOT' ] . '/layouts/nav-layout.php';
?>
<main id="localmain"> 
  <!--<input type="checkbox" id="lm-menustates">-->
  <div id="lm-content">
    <div class="lm-content-case"> </div>
  </div>
  <section class="indsec" id=""> <br>
    <div class="inddfsec" id="">
      <p> This page is RSS. </p>
    </div>
    <div class="inddfsec" id="">
      <h3>RSS</h3>
      <p><a href="https://rss.paotung.org">RSS订阅</a>&nbsp;&nbsp;<a href="https://drive.paotung.org">Drive磁碟</a></p>
      <br/>
    </div>
    <div class="inddfsec" id="">
      <h3>RSS</h3>
      <p><a href="https://rss.paotung.org">RSS订阅</a>&nbsp;&nbsp;<a href="https://drive.paotung.org">Drive磁碟</a></p>
      <br/>
    </div>
    <div class="inddfsec" id="">
      <h3>download1</h3>
      <p> paotung.org is a personal website, community activity with a mission to create,
        maintain, and promote schemas for structured data on the
        Internet, on web pages, in email messages, and beyond. </p>
      <p> <a href="https://www.paotung.org/index.html">paotung.org</a>&nbsp;&nbsp;&nbsp;<a href="https://www.paotung.org/index.html">paotung.org</a> </p>
      <br/>
    </div>
    <div class="inddfsec" id="">
      <h3>download2</h3>
      <p> paotung.org is a personal website, community activity with a mission to create,
        maintain, and promote schemas for structured data on the
        Internet, on web pages, in email messages, and beyond. </p>
      <p> <a href="https://www.paotung.org/index.html">paotung.org</a>&nbsp;&nbsp;&nbsp;<a href="https://www.paotung.org/index.html">paotung.org</a> </p>
      <br/>
    </div>
    <!-- mainContent -->
    <div class="inddfsec" id="">
      <h3>RSS</h3>
      <p>
		  <a href="/tools/probe/index.php">网站探针</a>&nbsp;&nbsp;
		  <a href="/tools/phpinfo/index.php">PHP信息</a>&nbsp;&nbsp;
		  <a href="/tools/speedtest/index.php">网速测试</a>&nbsp;&nbsp;
		  <a href="/tools/filemanager/index.php">文件管理</a>&nbsp;&nbsp;
		</p>
      <br/>
    </div>
  </section>
</main>
<?php
require_once $_SERVER[ 'DOCUMENT_ROOT' ] . '/layouts/footer-layout.php';
