Install php dependencies before use

****************************
apt install php-curl
apt install php-mbstring
apt install php-xml
****************************

http://joshdick.github.io/miniProxy/
https://github.com/joshdick/miniProxy