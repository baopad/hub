<?php
require_once $_SERVER[ 'DOCUMENT_ROOT' ] . '/layouts/var-layout.php';
require_once $_SERVER[ 'DOCUMENT_ROOT' ] . '/layouts/head-layout.php';
require_once $_SERVER[ 'DOCUMENT_ROOT' ] . '/layouts/nav-layout.php';
?>
<main id="localmain"> 
  <!--<input type="checkbox" id="lm-menustates">-->
  <div id="lm-content">
    <div class="lm-content-case"> </div>
  </div>
  <section class="indsec" id="">
    <div class="inddfsec" id="" style="display: none;">
      <div class="col-md-7">
        <div class=" ">
          <h2>本网站的作用</h2>
          <p class="intro"></p>
          <p>　　赋予的权利及其独特的国际性质，本网站可就人类面临的一系列问题采取行动，包括：</p>
          <ul class="ifgddvcro">
            <li class="intgdvcro"><a href="https://www.paotung.org/index.html">Maintain international peace and security</a></li>
            <li class="intgdvcro"><a href="https://www.paotung.org/index.html">Protect </a></li>
            <li class="intgdvcro"><a href="https://www.paotung.org/index.html">Deliver  aid</a></li>
            <li class="intgdvcro"><a href="https://www.paotung.org/index.html">Promote sustainable development</a></li>
            <li class="intgdvcro"><a href="https://www.paotung.org/index.html">Uphold&nbsp;international law</a></li>
          </ul>
          <p></p>
        </div>
      </div>
      <div class="col-md-7">
        <div class=" "> 
          <!--                    <div class="tabs">
                        <div class="tab-pane">
                            <input type="radio" name="tab" id="tab01" checked />
                            <label class="tab-item" for="tab01">tab01</label>
                            <div class="tab-content">111</div>
                        </div>
                        <div class="tab-pane">
                            <input type="radio" name="tab" id="tab02"/>
                            <label class="tab-item" for="tab02">tab02</label>
                            <div class="tab-content">222</div>
                        </div>
                        <div class="tab-pane">
                            <input type="radio" name="tab" id="tab03"/>
                            <label class="tab-item" for="tab03">tab03</label>
                            <div class="tab-content">333</div>
                        </div>
                    </div>-->
          <div class="hfhfnvbg">
            <div class="ghfggfdfdvd">
              <input type="radio" name="tab" id="tab01" checked="">
              <div class="gdfdfsdvd"> <img class="hgjkhkl" src="./unifil.jpg" alt=" " title="Photo/ICJ-CIJ">
                <h4 class="field-content purposes">Maintain International 77</h4>
              </div>
            </div>
            <div class="ghfggfdfdvd">
              <input type="radio" name="tab" id="tab02">
              <div class="gdfdfsdvd"> <img class="hgjkhkl" src="./22.jpg" alt=" " title="Photo/ICJ-CIJ">
                <h4 class="field-content purposes">Maintain International 7222222222222888</h4>
              </div>
            </div>
            <div class="ghfggfdfdvd">
              <input type="radio" name="tab" id="tab03">
              <div class="gdfdfsdvd"> <img class="hgjkhkl" src="./33.jpg" alt=" " title="Photo/ICJ-CIJ">
                <h4 class="field-content purposes">Maintain International 78833333338</h4>
              </div>
            </div>
          </div>
          <div class="owl-dots">
            <label class="tab-item" for="tab01">888
              <button role="button" class="owl-dot active"><span>1111</span></button>
            </label>
            <label class="tab-item" for="tab02">999
              <button role="button" class="owl-dot"><span>222</span></button>
            </label>
            <label class="tab-item" for="tab03">999
              <button role="button" class="owl-dot"><span>288888</span></button>
            </label>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section class="indsec" id="">
    <div class="inddfsec" id="" style="max-width: 996px;"><br>
		<div><a href="/"><span class="icon-home"></span></a>&nbsp;/&nbsp;<a href="/legal">legal</a>&nbsp;/&nbsp;Privacy Policy</div>
      <h2>Terms of Use</h2>
      <p>Last Update: October 18, 2021</p>
      <p>By visiting our site,you agree to be bound by the following terms and conditions (“Terms of Service”, “Terms”). including those additional terms and conditions and policies referenced herein and/or available by hyperlink. These Terms of Service apply to all users of the site, including without limitation users who are browsers, vendors, customers, merchants, and/ or contributors of content. Please read these Terms of Service carefully before accessing or using our website. By accessing or using any part of the site, you agree to be bound by these Terms of Service. If you do not agree to all the terms and conditions of this agreement, then you may not access the website or use any services. If these Terms of Service are considered an offer, acceptance is expressly limited to these Terms of Service. Any new features or tools which are added to the current store shall also be subject to the Terms of Service. You can review the most current version of the Terms of Service at any time on this page. We reserve the right to update, change or replace any part of these Terms of Service by posting updates and/or changes to our website. It is your responsibility to check this page periodically for changes. Your continued use of or access to the website following the posting of any changes constitutes acceptance of those changes.</p>
      <h3>PROHIBITED USES</h3>
      <p>In addition to other prohibitions as set forth in the Terms of Service, you are prohibited from using the site or its content: (a) for any unlawful purpose; (b) to solicit others to perform or participate in any unlawful acts; (c) to violate any international, federal, provincial or state regulations, rules, laws, or local ordinances; (d) to infringe upon or violate our intellectual property rights or the intellectual property rights of others; (e) to harass, abuse, insult, harm, defame, slander, disparage, intimidate, or discriminate based on gender, sexual orientation, religion, ethnicity, race, age, national origin, or disability; (f) to submit false or misleading information; (g) to upload or transmit viruses or any other type of malicious code that will or may be used in any way that will affect the functionality or operation of the Service or of any related website, other websites, or the Internet; (h) to collect or track the personal information of others; (i) to spam, phish, pharm, pretext, spider, crawl, or scrape; (j) for any obscene or immoral purpose; or (k) to interfere with or circumvent the security features of the Service or any related website, other websites, or the Internet. We reserve the right to terminate your use of the Service or any related website for violating any of the prohibited uses.</h3>

      <h3>DISCLAIMER OF WARRANTIES; LIMITATION OF LIABILITY</h3>
      <p>We do not guarantee, represent or warrant that your use of our service will be uninterrupted, timely, secure or error-free. We do not warrant that the results that may be obtained from the use of the service will be accurate or reliable. You agree that from time to time we may remove the service for indefinite periods of time or cancel the service at any time, without notice to you. You expressly agree that your use of, or inability to use, the service is at your sole risk. The service and all products and services delivered to you through the service are (except as expressly stated by us) provided ‘as is’ and ‘as available’ for your use, without any representation, warranties or conditions of any kind, either express or implied, including all implied warranties or conditions of merchantability, merchantable quality, fitness for a particular purpose, durability, title, and non-infringement. In no case shall wopet, our directors, officers, employees, affiliates, agents, contractors, interns, suppliers, service providers or licensors be liable for any injury, loss, claim, or any direct, indirect, incidental, punitive, special, or consequential damages of any kind, including, without limitation lost profits, lost revenue, lost savings, loss of data, replacement costs, or any similar damages, whether based in contract, tort (including negligence), strict liability or otherwise, arising from your use of any of the service or any products procured using the service, or for any other claim related in any way to your use of the service or any product, including, but not limited to, any errors or omissions in any content, or any loss or damage of any kind incurred as a result of the use of the service or any content (or product) posted, transmitted, or otherwise made available via the service, even if advised of their possibility. Because some states or jurisdictions do not allow the exclusion or the limitation of liability for consequential or incidental damages, in such states or jurisdictions, our liability shall be limited to the maximum extent permitted by law.</p>
      <h3>SEVERABILITY</h3>
      <p>In the event that any provision of these Terms of Service is determined to be unlawful, void or unenforceable, such provision shall nonetheless be enforceable to the fullest extent permitted by applicable law, and the unenforceable portion shall be deemed to be severed from these Terms of Service, such determination shall not affect the validity and enforceability of any other remaining provisions.</p>
      <h3>TERMINATION </h3>
      <p>The obligations and liabilities of the parties incurred prior to the termination date shall survive the termination of this agreement for all purposes. These Terms of Service are effective unless and until terminated by either you or us. You may terminate these Terms of Service at any time by notifying us that you no longer wish to use our Services, or when you cease using our site. If in our sole judgment you fail, or we suspect that you have failed, to comply with any term or provision of these Terms of Service, we also may terminate this agreement at any time without notice and you will remain liable for all amounts due up to and including the date of termination; and/or accordingly may deny you access to our Services (or any part thereof).</p>
      <h3>ENTIRE AGREEMENT</h3>
      <p>The failure of us to exercise or enforce any right or provision of these Terms of Service shall not constitute a waiver of such right or provision. These Terms of Service and any policies or operating rules posted by us on this site or in respect to The Service constitutes the entire agreement and understanding between you and us and govern your use of the Service, superseding any prior or contemporaneous agreements, communications and proposals, whether oral or written, between you and us (including, but not limited to, any prior versions of the Terms of Service). Any ambiguities in the interpretation of these Terms of Service shall not be construed against the drafting party.</p>
      <h3>GOVERNING LAW</h3>
      <p>These Terms of Service and any separate agreements whereby we provide you Services shall be governed by and construed in accordance with the laws of US.</p>
      <h3>CHANGES TO TERMS OF SERVICE</h3>
      <p>You can review the most current version of the Terms of Service at any time at this page. We reserve the right, at our sole discretion, to update, change or replace any part of these Terms of Service by posting updates and changes to our website. It is your responsibility to check our website periodically for changes. Your continued use of or access to our website or the Service following the posting of any changes to these Terms of Service constitutes acceptance of those changes. </p>
      <h3>CONTACT INFORMATION</h3>
      <p>info@paotung.org</p>
      <br/>
    </div>
    <!-- mainContent --> 
    
  </section>
</main>
<?php
require_once $_SERVER[ 'DOCUMENT_ROOT' ] . '/layouts/footer-layout.php';