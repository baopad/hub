<main id="localmain"> 
  <!--<input type="checkbox" id="lm-menustates">-->
  <div id="lm-content">
    <div class="lm-content-case"> </div>
  </div>
  <section class="indsec" id="">
    <div class="inddfsec" id="" style="display: none;">
      <div class="col-md-7">
        <div class=" ">
          <h2>本网站的作用</h2>
          <p class="intro"></p>
          <p>　　赋予的权利及其独特的国际性质，本网站可就人类面临的一系列问题采取行动，包括：</p>
          <ul class="ifgddvcro">
            <li class="intgdvcro"><a href="https://www.paotung.org/index.html">Maintain international peace and security</a></li>
            <li class="intgdvcro"><a href="https://www.paotung.org/index.html">Protect </a></li>
            <li class="intgdvcro"><a href="https://www.paotung.org/index.html">Deliver  aid</a></li>
            <li class="intgdvcro"><a href="https://www.paotung.org/index.html">Promote sustainable development</a></li>
            <li class="intgdvcro"><a href="https://www.paotung.org/index.html">Uphold&nbsp;international law</a></li>
          </ul>
          <p></p>
        </div>
      </div>
      <div class="col-md-7">
        <div class=" "> 
          <!--                    <div class="tabs">
                        <div class="tab-pane">
                            <input type="radio" name="tab" id="tab01" checked />
                            <label class="tab-item" for="tab01">tab01</label>
                            <div class="tab-content">111</div>
                        </div>
                        <div class="tab-pane">
                            <input type="radio" name="tab" id="tab02"/>
                            <label class="tab-item" for="tab02">tab02</label>
                            <div class="tab-content">222</div>
                        </div>
                        <div class="tab-pane">
                            <input type="radio" name="tab" id="tab03"/>
                            <label class="tab-item" for="tab03">tab03</label>
                            <div class="tab-content">333</div>
                        </div>
                    </div>-->
          <div class="hfhfnvbg">
            <div class="ghfggfdfdvd">
              <input type="radio" name="tab" id="tab01" checked="">
              <div class="gdfdfsdvd"> <img class="hgjkhkl" src="./unifil.jpg" alt=" " title="Photo/ICJ-CIJ">
                <h4 class="field-content purposes">Maintain International 77</h4>
              </div>
            </div>
            <div class="ghfggfdfdvd">
              <input type="radio" name="tab" id="tab02">
              <div class="gdfdfsdvd"> <img class="hgjkhkl" src="./22.jpg" alt=" " title="Photo/ICJ-CIJ">
                <h4 class="field-content purposes">Maintain International 7222222222222888</h4>
              </div>
            </div>
            <div class="ghfggfdfdvd">
              <input type="radio" name="tab" id="tab03">
              <div class="gdfdfsdvd"> <img class="hgjkhkl" src="./33.jpg" alt=" " title="Photo/ICJ-CIJ">
                <h4 class="field-content purposes">Maintain International 78833333338</h4>
              </div>
            </div>
          </div>
          <div class="owl-dots">
            <label class="tab-item" for="tab01">888
              <button role="button" class="owl-dot active"><span>1111</span></button>
            </label>
            <label class="tab-item" for="tab02">999
              <button role="button" class="owl-dot"><span>222</span></button>
            </label>
            <label class="tab-item" for="tab03">999
              <button role="button" class="owl-dot"><span>288888</span></button>
            </label>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section class="indsec" id="">
    <div class="inddfsec" id="" style="max-width: 996px;"><br>
      <div class="section-content">
        <div><a href="/"><span class="icon-home"></span></a>&nbsp;/&nbsp;<a href="/legal">legal</a></div>
        <div class="text-hero">
          <h1>PAOTUNG 法律信息</h1>
          <p class="typography-intro large-12 medium-12 small-12">查找PAOTUNG产品和服务的法律信息和资源。</p>
        </div>
        <figure class="image-hero"></figure>
      </div>
      <div  class="colding-ffical">
        <div class="colding-vertical">
          <figure class="icon-1492560273722 "></figure>
          <h2 class="title-space">Privacy Policy </h2>
          <p>关于产品购买、支持和维修的政策、条款及条件详细信息。</p>
          <p><a href="/legal/privacy.html" class="more">Explore Privacy Policy</a></p>
        </div>
        <div class="colding-vertical">
          <figure class="icon-1492560273722 "></figure>
          <h2 class="title-space">Terms of Use </h2>
          <p>关于产品购买、支持和维修的政策、条款及条件详细信息。</p>
          <p><a href="/legal/terms.html" class="more">Explore Terms of Use</a></p>
        </div>
      </div>
      <div  class="colding-ffical">
        <div class="colding-vertical">
          <figure class="icon-1492560273722 "></figure>
          <h2 class="title-space">Intellectual Property </h2>
          <p>关于产品购买、支持和维修的政策、条款及条件详细信息。</p>
          <p><a href="/legal/privacy.html" class="more">Explore Intellectual Property</a></p>
        </div>
        <div class="colding-vertical">
          <figure class="icon-1492560273722 "></figure>
          <h2 class="title-space">Ethics and Compliance </h2>
          <p>关于产品购买、支持和维修的政策、条款及条件详细信息。</p>
          <p><a href="/legal/terms.html" class="more">Explore Ethics and Compliance</a></p>
        </div>
      </div>
      
      <h3>Applicable Laws</h3>
      <p>This website will protect your Personal Information in accordance with all applicable laws.</p>
      <h3>Contact Us</h3>
      <p>info@paotung.org</p>
      <br/>
    </div>
    <!-- mainContent --> 
    
  </section>
</main>
