<?php
/***********************************************************
Copyright info@paotung.org.
Licensed under MIT.
***********************************************************/

//Additional CSS styles, inside the head element.
$addhead_css = ['<link rel="stylesheet" href="assets/head.add.css">'];
//Additional Javascript styles, inside the head element.
$addhead_js = ['<script src="assets/head.add.js"></script>'];
//Additional the Body element class.
$addbody_class = [' ' , ' '];
//Additional Javascript styles, after the foot element.
$addfooter_js = ['<script src="assets/footer.add.js"></script>'];




//Import pre-variable.
require_once $_SERVER[ 'DOCUMENT_ROOT' ] . '/layouts/var-layout.php';
//Import header elements.
require_once $_SERVER[ 'DOCUMENT_ROOT' ] . '/layouts/head-layout.php';
//Import navigation bar
require_once $_SERVER[ 'DOCUMENT_ROOT' ] . '/layouts/nav-layout.php';
//Importing local elements
require_once __DIR__ . '/index/local.php';
//Importing footer elements
require_once $_SERVER[ 'DOCUMENT_ROOT' ] . '/layouts/footer-layout.php';