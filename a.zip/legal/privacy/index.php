<?php
require_once $_SERVER[ 'DOCUMENT_ROOT' ] . '/layouts/var-layout.php';
require_once $_SERVER[ 'DOCUMENT_ROOT' ] . '/layouts/head-layout.php';
require_once $_SERVER[ 'DOCUMENT_ROOT' ] . '/layouts/nav-layout.php';
?>
<main id="localmain"> 
  <!--<input type="checkbox" id="lm-menustates">-->
  <div id="lm-content">
    <div class="lm-content-case"> </div>
  </div>
  <section class="indsec" id="">
    <div class="inddfsec" id="" style="display: none;">
      <div class="col-md-7">
        <div class=" ">
          <h2>本网站的作用</h2>
          <p class="intro"></p>
          <p>　　赋予的权利及其独特的国际性质，本网站可就人类面临的一系列问题采取行动，包括：</p>
          <ul class="ifgddvcro">
            <li class="intgdvcro"><a href="https://www.paotung.org/index.html">Maintain international peace and security</a></li>
            <li class="intgdvcro"><a href="https://www.paotung.org/index.html">Protect </a></li>
            <li class="intgdvcro"><a href="https://www.paotung.org/index.html">Deliver  aid</a></li>
            <li class="intgdvcro"><a href="https://www.paotung.org/index.html">Promote sustainable development</a></li>
            <li class="intgdvcro"><a href="https://www.paotung.org/index.html">Uphold&nbsp;international law</a></li>
          </ul>
          <p></p>
        </div>
      </div>
      <div class="col-md-7">
        <div class=" "> 
          <!--                    <div class="tabs">
                        <div class="tab-pane">
                            <input type="radio" name="tab" id="tab01" checked />
                            <label class="tab-item" for="tab01">tab01</label>
                            <div class="tab-content">111</div>
                        </div>
                        <div class="tab-pane">
                            <input type="radio" name="tab" id="tab02"/>
                            <label class="tab-item" for="tab02">tab02</label>
                            <div class="tab-content">222</div>
                        </div>
                        <div class="tab-pane">
                            <input type="radio" name="tab" id="tab03"/>
                            <label class="tab-item" for="tab03">tab03</label>
                            <div class="tab-content">333</div>
                        </div>
                    </div>-->
          <div class="hfhfnvbg">
            <div class="ghfggfdfdvd">
              <input type="radio" name="tab" id="tab01" checked="">
              <div class="gdfdfsdvd"> <img class="hgjkhkl" src="./unifil.jpg" alt=" " title="Photo/ICJ-CIJ">
                <h4 class="field-content purposes">Maintain International 77</h4>
              </div>
            </div>
            <div class="ghfggfdfdvd">
              <input type="radio" name="tab" id="tab02">
              <div class="gdfdfsdvd"> <img class="hgjkhkl" src="./22.jpg" alt=" " title="Photo/ICJ-CIJ">
                <h4 class="field-content purposes">Maintain International 7222222222222888</h4>
              </div>
            </div>
            <div class="ghfggfdfdvd">
              <input type="radio" name="tab" id="tab03">
              <div class="gdfdfsdvd"> <img class="hgjkhkl" src="./33.jpg" alt=" " title="Photo/ICJ-CIJ">
                <h4 class="field-content purposes">Maintain International 78833333338</h4>
              </div>
            </div>
          </div>
          <div class="owl-dots">
            <label class="tab-item" for="tab01">888
              <button role="button" class="owl-dot active"><span>1111</span></button>
            </label>
            <label class="tab-item" for="tab02">999
              <button role="button" class="owl-dot"><span>222</span></button>
            </label>
            <label class="tab-item" for="tab03">999
              <button role="button" class="owl-dot"><span>288888</span></button>
            </label>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section class="indsec" id="">
    <div class="inddfsec" id="" style="max-width: 996px;"><br>
		<div><a href="/"><span class="icon-home"></span></a>&nbsp;/&nbsp;<a href="/legal">legal</a>&nbsp;/&nbsp;Privacy Policy</div>
      <h2>Privacy Policy</h2>
      <p>Last Update: October 18, 2021</p>
      <p>This Privacy Policy is administered and maintained by this website. Protecting your privacy is important. By ensuring that you are aware of and understand this Privacy Policy, we can provide you with better service. Please take a moment to read this Privacy Policy to learn how we handle your personally identifiable information.</p>
      <h3>General Personal Information Collection</h3>
      <p>We may collect your personally identifiable information ("Personal Information") when you use any of our Websites or interact with us in person. We respect all Personal Information we collect, whether it be from our customers, users, third party service providers, employees, or applicants. Personal Information we collect may include your name, mailing address, phone number, e-mail address, company name, business type, payment details, health-related data, and other information you provide to us (for example in a contact form). When ordering a product or requesting service information, participating in certain promotional activities or research studies to improve our products, completing surveys, and corresponding with us, we may ask for certain Personal Information. When we ask you to provide Personal Information, it will be clear what Personal Information we are requesting.</p>
      <h3>Use of Your Personal Information</h3>
      <p>We may use Personal Information for promotional activities (including, but not limited to, advertising, contests, surveys, and promotions), to respond to customer inquiries, to process orders, to improve our products or provide technical support, for statistical purposes, to provide important notices, and to contact you or manage our relationship with you.</p>
      <p>We may also use your Personal Information when you visit any of our Websites or click on advertisements or promotional areas on any of our Websites. We may use your Personal Information to help run our Websites more efficiently, to gather broad demographic information, to monitor the nature and level of activity on our Websites, to contact you regarding our products and services, and to evaluate the effectiveness of advertising and promotion. When practicable, we use Personal Information obtained from your browsing of our Websites on an aggregate basis, without associating that information to your name, unless you expressly consent otherwise.</p>
      <h3>Browsing</h3>
      <p>We may also collect information that is provided to us by your browser or your interaction with any of our Websites. This may include information on the browser you used to come to any of our Websites, the Uniform Resource Locator ("URL") of the website that you visited just before visiting our Website, which pages on any of our Websites you visit, your activities on any of our Websites, any search terms you entered, which URL you go to next, and your Internet Protocol ("IP") address. Please also see the Section of this policy below captioned "Tracking Technologies" for more information.</p>
      <h3>Newsletters and Promotional E-mails</h3>
      <p>As a service to our customers, we may e-mail you newsletters, promotional information and other information, using your Personal Information collected online. These e-mails will only be sent to you if you have agreed to receive them. You may choose to stop receiving our newsletter or marketing emails by following the unsubscribe instructions included in these emails, accessing the email preferences in your account settings page.</p>
      <h3>Blog / Forums</h3>
      <p>Some of our Websites offer publicly accessible blogs or community forums. You should be aware that any information you provide in these areas may be read, collected, and used by others who access them. To request removal of your Personal Information from our blog or community forum. In some cases, we may not be able to remove your Personal Information, in which case we will let you know if we are unable to do so and why.</p>
      <h3>Sharing your Personal Information</h3>
      <p>We will share your Personal Information with third parties only in the ways that are described in this Privacy Policy. Unless we have your permission, we will share the Personal Information you provide only with other this website, including in particular, sending of marketing communications, providing customer service, supporting our marketing and product distribution, or operating our systems or applications. These companies are authorized to use your personal information only as necessary to provide these services. uses of your Personal Information, and choices you may have regarding your Personal Information. We may also disclose your Personal Information to any other third party with your prior consent.</p>
      <h3>User Access and Choice</h3>
      <p>Upon request, we will provide you with information about whether we hold any of your Personal Information. If your Personal Information changes you may correct, update, or amend, your information by making the change in your account profile page or by emailing our Customer Support by or by contacting us by telephone or postal mail using the contact information listed below. Also, if you wish to delete/remove your information, ask to have it removed from a public forum, directory or testimonial on our Websites, or deactivate an account you can do so by making the change in your account profile page or by emailing our Customer Support by or by contacting us by telephone or postal mail using the contact information listed below. We will respond to your request within a reasonable timeframe.</p>
      <h3>Tracking Technologies</h3>
      <p>As is true of most websites, we gather certain information automatically. This information may include IP addresses, browser type, internet service provider ("ISP"), referring/exit pages, the files viewed on our site (e.g., HTML pages, graphics, etc.), operating system, date/time stamp, and/or clickstream data to analyze trends in the aggregate and administer the site.</p>
      <p>This website use cookies or similar technologies such as cookies, web beacons, tags, and scripts, to analyze trends, administer the Websites, track users' movements around the Websites, and gather demographic information about our user base as a whole. We may receive reports based on the use of these technologies by these companies on an individual and aggregated basis. You can control the use of cookies at the individual browser level, but if you choose to disable cookies, it may limit your use of certain features or functions on our Websites.</p>
      <p>A "cookie" is a small data file that a website can send to your browser, which may then be stored on your system. We use cookies to better serve you when you return to any of our Websites. Some of our web pages may send cookies when you visit any of our Websites, make purchases, respond to online surveys or promotions, participate in a contest, or request information. Accepting the cookies used on any of our Websites enables our web server to identify your system by reading the cookie that has been stored on your system. Cookies that are placed when visiting any of our Websites cannot be used to obtain your Personal Information at another site.</p>
      <p>The information collected online permits us to analyze traffic patterns on any of our Websites and is used on an aggregate basis. This can enable us over time to provide users with a better experience on any of our Websites by improving the content and making it easier to use. The information collected online also allows us to contact you regarding our products and services that may be responsive to your needs or browsing history.</p>
      <p>Depending on the browser used, you can set your browser to notify you before you receive a cookie, giving you the chance to decide whether to accept it, and you can also set your browser to turn off cookies. However, if you do so, some areas of our Websites may not function properly, or you will be required to re-enter your Personal Information to use an area of our Websites.</p>
      <p>We may also use web beacon technologies to better tailor our Websites to provide better customer service. A web beacon is a single pixel GIF that allows a website to count users who have visited that page or accessed certain cookies. These web beacons may be placed on specific pages across any of our Websites. When a visitor accesses these pages, a notice of that visit is generated which may be processed by us or by our third party service providers. These web beacons work in conjunction with cookies. If you do not want to associate your cookie information with your visits to these pages, depending on the browser used, you can set your browser to turn off cookies.</p>
      <h3>Protecting your Personal Information</h3>
      <p>While Renesas does not guarantee that unauthorized access will never occur, Renesas does take care in maintaining the security of your Personal Information and in preventing unauthorized access to it, both during transmission and once it is received. If you have any questions about the security of your Personal Information, you can contact us by clicking here.</p>
      <h3>Data Retention</h3>
      <p>We will retain your Personal Information for as long as your account is active or as needed to provide you services. We will retain and use your Personal Information as necessary to comply with our legal obligations, resolve disputes, and enforce our agreements.</p>
      <h3>Links to Third-Party Websites</h3>
      <p>Parts of our Websites may contain links to third-party websites for your convenience and information. The privacy practices of these third party websites may differ from those of Renesas. When you access these other websites, please understand that we do not control the content and are not responsible for the privacy practices of that website. We suggest that you carefully review the privacy policies of each website you visit. This Privacy Policy does not cover the information practices of those websites to which our Websites link. These other websites may send their own cookies to users, collect data, or solicit Personal Information.</p>
      <h3>Changes to this Policy</h3>
      <p>This website reserves the right to change this Privacy Policy at any time and for any reason. Any such changes will be posted in this Privacy Policy. If we make any material changes we will notify you by email (sent to the e-mail address specified in your account) or by means of a notice on this Website prior to the change becoming effective. We encourage you to periodically review this page for the latest information on our privacy practices.</p>
      <h3>Applicable Laws</h3>
      <p>This website will protect your Personal Information in accordance with all applicable laws.</p>
      <h3>Contact Us</h3>
      <p>legal@paotung.org</p>
      <br/>
    </div>
    <!-- mainContent --> 
    
  </section>
</main>
<?php
require_once $_SERVER[ 'DOCUMENT_ROOT' ] . '/layouts/footer-layout.php';