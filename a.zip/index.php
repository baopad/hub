<?php
/***********************************************************
Copyright info@paotung.org.
Licensed under MIT.
***********************************************************/

require __DIR__ . '/index/index.php';